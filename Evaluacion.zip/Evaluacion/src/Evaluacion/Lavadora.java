package Evaluacion;

public class Lavadora extends Electrodomestico{
	private int carga;

	protected final static int cargaDef =5;
	//Constructor por defecto 
	public Lavadora() {
		this.carga =cargaDef;
	}

	public Lavadora(int preciobase, int peso) {
		super(preciobase, peso);
	}

	public Lavadora(int preciobase, String color, char consumo, int peso, int carga) {
		super(preciobase, color, consumo, peso);
		this.carga = carga;
	}

	public int getCarga() {
		return carga;
	}

	public int precioFinal() {	
		int precio=super.precioFinal();

		if(carga>30) {
		precio = precio + 40000;
		}
		return precio;
	}
	
	
	
}

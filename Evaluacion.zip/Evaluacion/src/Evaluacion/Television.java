package Evaluacion;

public class Television extends Electrodomestico{
	private int resolucion = 20;
	private boolean sintonizadorTDT = false;
	
	public Television() {
		super();
	}

	public Television(int preciobase, int peso) {
		super(preciobase, peso);
	}

	public Television(int preciobase, String color, char consumo, int peso, int resolucion, boolean sintonizadorTDT) {
		super(preciobase, color, consumo, peso);
		this.resolucion = resolucion;
		this.sintonizadorTDT = sintonizadorTDT;
	}

	public int getResolucion() {
		return resolucion;
	}

	public boolean isSintonizadorTDT() {
		return sintonizadorTDT;
	}
	
	public int precioFinal() {
	int precio= super.precioFinal();
	double x;
	
	if(sintonizadorTDT == true)
			precio = precio + 45000;
	if(resolucion>40) {	
			x=precio*1.3;
			precio=(int)Math.round(x);			
	}
		return precio;
	}
}

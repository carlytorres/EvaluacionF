package Evaluacion;

public class Principal {
public static void main(String[] args) {
	int totalelect = 0;
	int totallav = 0;
	int totaltv = 0;
	
	Electrodomestico e[] = new Electrodomestico[10];
	
	e[0] = new Electrodomestico(50000, "azul", 'b', 100);
	e[1] = new Lavadora(50000,10);
	e[2] = new Television(50000, "negro", 'a', 20, 50, true);
	e[3] = new Electrodomestico(100000, "blanco", 'c', 40);
	e[4] = new Lavadora(150000, 50);
	e[5] = new Television(50000, "gris", 'a', 20, 32, false);
	e[6] = new Electrodomestico(50000, "azul", 'b', 100);
	e[7] = new Lavadora(70000, 65);
	e[8] = new Television(50000, "negro", 'a', 20, 50, true);
	e[9] = new Electrodomestico(100000, "blanco", 'c', 40);
	
	
	for(int i=0;i<10;i++) {
		if(e[i] instanceof Electrodomestico) {
			totalelect = totalelect + e[i].precioFinal();
		}
		if(e[i] instanceof Lavadora) {
			totallav = totallav + e[i].precioFinal();
		}
		if(e[i] instanceof Television) {
			totaltv = totaltv + e[i].precioFinal();
		}
	}
		
		System.out.println("Total electrodomesticos : " +  totalelect);	
		System.out.println("Total lavadoras : " +  totallav);
		System.out.println("Total televisores : " +  totaltv);
	
}
}

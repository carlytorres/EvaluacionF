package Evaluacion;


public class Electrodomestico {
	private int preciobase;
	private String color;
	private char consumo;
	private int peso ;
	
	protected final static int preciobaseDef=100000;
	protected final static String colorDef = "blanco";
	protected final static char consumoDef = 'F';
	protected final static int pesoDef =5 ;
	

	public Electrodomestico() {
		this(preciobaseDef,colorDef,consumoDef,pesoDef);
	}
	
	//Constructor precio y peso
	public Electrodomestico(int preciobase, int peso) {
		super();
		this.preciobase = preciobase;
		this.peso = peso;
	}
	//Constructor todos los atributos
	public Electrodomestico(int preciobase, String color, char consumo, int peso) {
		super();
		this.preciobase = preciobase;
		this.color = color;
		this.consumo = consumo;
		this.peso = peso;
	}
	
	//Metodos getters
	public int getPreciobase() {
		return preciobase;
	}
	public String getColor() {
		return color;
	}
	public char getConsumo() {
		return consumo;
	}
	public int getPeso() {
		return peso;
	}
	
	public void comprobarConsumoEnergetico(char letra) {
		letra = Character.toUpperCase(letra);
		if(letra>='A' && letra<='F') 
			this.consumo = letra;
		else
			this.consumo = consumoDef;
	}

	public void comprobarColor(String color) {
		String colores[]= {"blanco","negro","rojo","azul","gris"};
		for(int i=0;i<5;i++) {
			if(color.equalsIgnoreCase(colores[i])) {
				this.color = color;
				break;
			}else
				this.color = colorDef;			
		}
	}
	
	public int precioFinal() {
		int precio=preciobase;
		consumo = Character.toUpperCase(consumo);
		if (consumo == 'A')
			precio = precio + 85000;
		if (consumo == 'B')
			precio = precio + 70000;
		if (consumo == 'C') 
			precio = precio + 50000;
		if (consumo == 'D')
			precio = precio + 40000;
		if (consumo == 'E')
			precio = precio + 25000;
		if (consumo == 'F')
			precio = precio + 8500;

		if(peso>=0 && peso<=19) 
			precio = precio + 8500;
		
		if(peso>=20 && peso<=49) 
			precio = precio + 40000;

		if(peso>=50 && peso<=79) 
			precio= precio + 70000;

		if(peso>=80) 
			precio = precio +85000;


		return precio;
		
	}
	
	
	
}